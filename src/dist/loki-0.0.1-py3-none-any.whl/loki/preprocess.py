import scanpy as sc
import numpy as np
import pandas as pd
import json



def get_library_id(adata):
    """
    Retrieves the library ID from the AnnData object, assuming it contains spatial data.
    The function will return the first library ID found in `adata.uns['spatial']`.

    :param adata: AnnData object containing spatial information in `adata.uns['spatial']`.
    :return: The first library ID found in `adata.uns['spatial']`.
    :raises: 
            AssertionError: If 'spatial' is not present in `adata.uns`.
            Logs an error if no library ID is found.
    """
    
    # Check if 'spatial' is present in adata.uns; raises an error if not found
    assert 'spatial' in adata.uns, "spatial not present in adata.uns"
    
    # Retrieve the list of library IDs (which are keys in the 'spatial' dictionary)
    library_ids = adata.uns['spatial'].keys()
    
    try:
        # Attempt to return the first library ID (converting the keys object to a list)
        library_id = list(library_ids)[0]
        return library_id
    except IndexError:
        # If no library IDs exist, log an error message
        logger.error('No library_id found in adata')



def get_scalefactors(adata, library_id=None):
    """
    Retrieves the scalefactors from the AnnData object for a given library ID. If no library ID is provided, 
    the function will automatically retrieve the first available library ID.

    :param adata: AnnData object containing spatial data and scalefactors in `adata.uns['spatial']`.
    :param library_id: The library ID for which the scalefactors are to be retrieved. If not provided, it defaults to the first available ID.
    :return: A dictionary containing scalefactors for the specified library ID.
    """
    
    # If no library_id is provided, retrieve the first available library ID
    if library_id is None:
        library_id = get_library_id(adata)
    
    try:
        # Attempt to retrieve the scalefactors for the specified library ID
        scalef = adata.uns['spatial'][library_id]['scalefactors']
        return scalef
    except KeyError:
        # Log an error if the scalefactors or library ID is not found
        logger.error('scalefactors not found in adata')



def get_spot_diameter_in_pixels(adata, library_id=None):
    """
    Retrieves the spot diameter in pixels from the AnnData object's scalefactors for a given library ID.
    If no library ID is provided, the function will automatically retrieve the first available library ID.

    :param adata: AnnData object containing spatial data and scalefactors in `adata.uns['spatial']`.
    :param library_id: The library ID for which the spot diameter is to be retrieved. If not provided, defaults to the first available ID.
    
    :return: The spot diameter in full resolution pixels, or None if not found.
    """
    
    # Get the scalefactors for the specified or default library ID
    scalef = get_scalefactors(adata, library_id=library_id)
    
    try:
        # Attempt to retrieve the spot diameter in full resolution from the scalefactors
        spot_diameter = scalef['spot_diameter_fullres']
        return spot_diameter    
    except TypeError:
        # Handle case where `scalef` is None or invalid (if get_scalefactors returned None)
        pass
    except KeyError:
        # Log an error if the 'spot_diameter_fullres' key is not found in the scalefactors
        logger.error('spot_diameter_fullres not found in adata')



def prepare_data_for_alignment(data_path, scale_type='tissue_hires_scalef'):
    """
    Prepares data for alignment by reading an AnnData object and preparing the high-resolution tissue image.

    :param data_path: The path to the AnnData (.h5ad) file containing the Visium data.
    :param scale_type: The type of scale factor to use (`tissue_hires_scalef` by default).
    
    :return:
        - ad: AnnData object containing the spatial transcriptomics data.
        - ad_coor: Numpy array of scaled spatial coordinates (adjusted for the specified resolution).
        - img: High-resolution tissue image, normalized to 8-bit unsigned integers.
    
    :raises: 
            ValueError: If required data (e.g., scale factors, spatial coordinates, or images) is missing.
    """
    
    # Load the AnnData object from the specified file path
    ad = sc.read_h5ad(data_path)
    
    # Ensure the variable (gene) names are unique to avoid potential conflicts
    ad.var_names_make_unique()
    
    try:
        # Retrieve the specified scale factor for spatial coordinates
        scalef = get_scalefactors(ad)[scale_type]
    except KeyError:
        raise ValueError(f"Scale factor '{scale_type}' not found in ad.uns['spatial']")
    
    # Scale the spatial coordinates using the specified scale factor
    try:
        ad_coor = np.array(ad.obsm['spatial']) * scalef
    except KeyError:
        raise ValueError("Spatial coordinates not found in ad.obsm['spatial']")
    
    # Retrieve the high-resolution tissue image
    try:
        img = ad.uns['spatial'][get_library_id(ad)]['images']['hires']
    except KeyError:
        raise ValueError("High-resolution image not found in ad.uns['spatial']")
    
    # If the image values are normalized to [0, 1], convert to 8-bit format for compatibility
    if img.max() < 1.1:
        img = (img * 255).astype('uint8')
    
    return ad, ad_coor, img



def load_data_for_annotation(st_data_path, json_path, in_tissue=True):
    """
    Loads spatial transcriptomics (ST) data from an .h5ad file and prepares it for annotation.

    :param sample_type: The type or category of the sample (used to locate the data in the directory structure).
    :param sample_name: The name of the sample (used to locate specific files).
    :param in_tissue: Boolean flag to filter the data to include only spots that are in tissue. Default is True.
    
    :return:
        - st_ad: AnnData object containing the spatial transcriptomics data, with spatial coordinates in `obs`.
        - library_id: The library ID associated with the spatial data.
        - roi_polygon: Region of interest polygon loaded from a JSON file for further annotation or analysis.
    """

    # Load the spatial transcriptomics data into an AnnData object
    st_ad = sc.read_h5ad(st_data_path)
    
    # Optionally filter the data to include only spots that are within the tissue
    if in_tissue:
        st_ad = st_ad[st_ad.obs['in_tissue'] == 1]
    
    # Initialize pixel coordinates for spatial information
    st_ad.obs[["pixel_y", "pixel_x"]] = None  # Ensure the columns exist
    st_ad.obs[["pixel_y", "pixel_x"]] = st_ad.obsm['spatial']  # Copy spatial coordinates into obs
    
    # Retrieve the library ID associated with the spatial data
    library_id = get_library_id(st_ad)
    
    # Load the region of interest (ROI) polygon from a JSON file
    with open(json_path) as f:
        roi_polygon = json.load(f)

    return st_ad, library_id, roi_polygon


