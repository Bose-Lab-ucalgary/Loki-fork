Please find the source code under the `./src/loki` folder. Please install required packages listed in `./src/requirements.txt` to run the notebooks, with python verison 3.9. Pretrain weights of OmiCLIP can be found on codeocean.

The website of Loki can be viewed by open `./docs/build/html/index.html`.
